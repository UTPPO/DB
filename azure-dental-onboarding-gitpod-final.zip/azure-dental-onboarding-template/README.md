# Dental Onboarding — Gitpod Demo (Final)
Open via: https://gitpod.io/#https://github.com/<YOUR-USER>/<YOUR-REPO>
- Blob trigger runs in one terminal (Azurite + Functions)
- SQLite importer runs in another and writes scripts/out_report.json
Edit data/*.json or scripts/field_map.json to experiment.
